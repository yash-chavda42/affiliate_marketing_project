<?php
	$con = mysqli_connect("localhost","root","","login_db");
     /*if(!$con){
         echo "<script>alert('Connection is failed')</script>";
     }
     else{
        echo "<script>alert('Connection is Done')</script>";
     }*/
?>